package com.greatlearning.EmployeeManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.greatlearning.EmployeeManagement.model.Employee;
import com.greatlearning.EmployeeManagement.service.EmployeeServiceImpl;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl employeeServiceImpl;

	/*
	 * 4. Your application should provide an endpoint to list all the employees
	 * stored in the database.
	 */

	@GetMapping("/getList")
	public List<Employee> getAll() {
		return employeeServiceImpl.get();
	}

	/*
	 * 3. Now Your application should be able to add employees data in the db if and
	 * only if the authenticated user is ADMIN
	 */

	@PostMapping("/addEmployee")
	public void addEmployee(String firstName, String lastName, String email) {
		employeeServiceImpl.addEmployee(firstName, lastName, email);
	}

	/*
	 * 7. Your application should also provide an endpoint to delete an existing
	 */

	@DeleteMapping("/deleteEmployee")
	public String deleteEmployee(@RequestParam("id") int theId) {
		employeeServiceImpl.deleteEmployee(theId);
		return "Deleted employee id - " + theId;
	}

	/*
	 * 6. Your application should provide an endpoint to update an existing employee
	 * record with the given updated json object.
	 */

	@PostMapping("/updateEmployee")
	public Employee updateEmployee(@RequestBody Employee employee) {
		employeeServiceImpl.updateEmployee(employee);
		return employee;
	}

	/*
	 * 5. Your application should provide endpoint to fetch or get an employee
	 * record specifically based on the id of that employee
	 */

	@GetMapping("/findById")
	public Optional<Employee> findById(@RequestParam("id") int theId) {
		return employeeServiceImpl.searchById(theId);
	}

	/*
	 * Your application should provide an endpoint to fetch an employee by his/her
	 * first name and if found more than one record then list them all -
	 */

	@GetMapping("/findByFirstName")
	public List<Employee> findByFirstName(@RequestParam("firstName") String fname) {
		return employeeServiceImpl.searchByFirstName(fname);
	}

	/*
	 * 9. Your application should be able to list all employee records sorted on the
	 * basis of first name either in ascending or descendin order
	 */

	@GetMapping("/getSortedByName")
	public List<Employee> getSortByName(Direction direction) {
		return employeeServiceImpl.getEmployeeByFirstNameOrder(direction);
	}

}
