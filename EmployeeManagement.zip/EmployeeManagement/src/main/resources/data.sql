insert into employee values (1, 'isha@example.com', 'isha', 'agarwal');
insert into employee values (2, 'gl@example.com', 'great', 'learning');